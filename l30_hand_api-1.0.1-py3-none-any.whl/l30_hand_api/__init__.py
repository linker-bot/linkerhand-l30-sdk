"""
L30 Hand API - A Python API for controlling the L30 robotic hand
"""

from .hand_api import L30HandAPI
 
__version__ = "1.0.0"
__all__ = ["L30HandAPI"] 