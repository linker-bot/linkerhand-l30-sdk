#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""机械手关节映射配置"""

# 关节配置 {列名: [ID, 最小角度, 最大角度, 列序号, 角度方向]}
# 角度方向: 1表示正向映射(关节角度=电机角度-校准值)，-1表示负向映射(关节角度=校准值-电机角度)
JOINT_CONFIG = {
    # 拇指
    '大拇指侧摆': [3, 0, 40, 1, 1],      # 负向
    '拇指旋转': [4, 0, 80, 2, 1],       # 负向
    '拇指弯曲': [1, 0, 70, 3, 1],        # 正向
    '拇指指尖': [2, 0, 60, 4, 1],         # 正向
    # 食指
    '食指侧摆': [14, -30, 30, 5, 1],     # 负向
    '食指指根弯曲': [15, 0, 80, 6, 1],    # 负向
    '食指指尖': [16, 0, 80, 7, 1],       # 负向
    # 中指
    '中指侧摆': [13, -30, 30, 8, 1],      # 负向
    '中指指根': [8, 0, 80, 9, 1],        # 负向
    '中指指尖': [9, 0, 80, 10, 1],      # 负向
    # 无名指
    '无名指侧摆': [5, -30, 30, 11, -1],    # 正向
    '无名指指根': [7, 0, 80, 12, 1],      # 负
    '无名指指尖': [6, 0, 80, 13, 1],      # 正向
    # 小指
    '小指侧摆': [12, -30, 30, 14, 1],     # 负向
    '小指指根': [10, 0, 80, 15, 1],       # 正向
    '小指指尖': [11, 0, 80, 16, 1],      # 负向
    # 手腕
    '手腕': [17, -50, 50, 17, 1]          # 正向
}

# 关节分组
GROUPS = {
    '拇指': [3, 4, 1, 2],
    '食指': [14, 15, 16],
    '中指': [13, 8, 9],
    '无名指': [5, 7, 6],
    '小指': [12, 10, 11],
    '手腕': [17],
    '侧摆': [3, 14, 13, 5, 12],
    '指根': [1, 15, 8, 7, 10],
    '指尖': [2, 16, 9, 6, 11]
}

def get_joint_info(joint_id):
    """获取关节信息"""
    for name, (id_, min_, max_, _, direction) in JOINT_CONFIG.items():
        if id_ == joint_id:
            return {
                'name': name,
                'range': (min_, max_),
                'direction': direction
            }
    return None

def get_table_columns():
    """获取表格列名（按序号排序）"""
    columns = ['序号'] + [name for name, cfg in sorted(JOINT_CONFIG.items(), key=lambda x: x[1][3])]
    return columns

def get_motor_id(column_name):
    """获取列名对应的电机ID"""
    return JOINT_CONFIG.get(column_name, [None])[0]

def get_angle_direction(joint_id):
    """获取关节角度映射方向"""
    for cfg in JOINT_CONFIG.values():
        if cfg[0] == joint_id:
            return cfg[4]
    return None

def joint_to_motor_angle(joint_id, joint_angle, calibration_value):
    """将关节角度转换为电机角度
    
    Args:
        joint_id: 关节ID
        joint_angle: 关节角度
        calibration_value: 校准值
    
    Returns:
        电机角度
    """
    direction = get_angle_direction(joint_id)
    if direction is None:
        return joint_angle
    return calibration_value + (direction * joint_angle)

def motor_to_joint_angle(joint_id, motor_angle, calibration_value):
    """将电机角度转换为关节角度
    
    Args:
        joint_id: 关节ID
        motor_angle: 电机角度
        calibration_value: 校准值
    
    Returns:
        关节角度
    """
    direction = get_angle_direction(joint_id)
    if direction is None:
        return motor_angle
    return direction * (motor_angle - calibration_value) 