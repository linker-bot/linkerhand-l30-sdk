#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
L30HandAPI - L30机械手控制API
此模块提供了与L30机械手通信和控制的所有功能
"""

import os
import sys
import time
import csv
import json
import serial
import serial.tools.list_ports
from typing import Dict, List, Tuple, Union, Optional
import platform

# 设置所有必要的系统路径
current_dir = os.path.dirname(os.path.abspath(__file__))

# 添加SDK相关路径
sdk_root = os.path.join(current_dir, "DynamixelSDK-3.8.3")
sdk_python_path = os.path.join(sdk_root, "python", "src")

# 将所有必要的路径添加到系统路径
for path in [current_dir, sdk_root, sdk_python_path]:
    if path not in sys.path:
        sys.path.append(path)

# 导入Dynamixel相关模块
from .sdk.robotis_def import *
from .sdk.port_handler import *
from .sdk.packet_handler import *
from .sdk.group_sync_write import *
from .sdk.group_sync_read import *
# 延迟导入，避免在模块加载时就固定HAND_TYPE
# from motor_mapping import *  # 导入电机映射配置

# Dynamixel电机控制表地址定义
ADDR_OPERATING_MODE = 11  # 操作模式地址
ADDR_TORQUE_ENABLE = 64  # 扭矩使能地址
ADDR_GOAL_POSITION = 116  # 目标位置地址
ADDR_PRESENT_POSITION = 132  # 当前位置地址
ADDR_MOVING = 122  # 运动状态地址
ADDR_PROFILE_VELOCITY = 112  # 速度控制地址
ADDR_HOMING_OFFSET = 20  # 原点偏移地址
ADDR_HARDWARE_ERROR = 70  # 硬件错误状态地址
ADDR_POSITION_P_GAIN = 84  # 位置控制P增益地址
ADDR_POSITION_I_GAIN = 82  # 位置控制I增益地址
ADDR_POSITION_D_GAIN = 80  # 位置控制D增益地址

# 协议版本和通信参数设置
PROTOCOL_VERSION = 2.0  # Dynamixel协议2.0版本
BAUDRATE = 1000000  # 串口波特率1M
DEFAULT_VELOCITY = 255  # 默认速度（最大值）
MAX_VELOCITY = 1000  # 最大速度值
DEFAULT_INTERVAL = 0.2  # 默认动作间隔时间（秒）

# 电机控制参数
TORQUE_ENABLE = 1  # 扭矩使能
TORQUE_DISABLE = 0  # 扭矩禁用
DXL_MINIMUM_POSITION_VALUE = 0  # 最小位置值
DXL_MAXIMUM_POSITION_VALUE = 4095  # 最大位置值（12位分辨率）
EXTENDED_POSITION_CONTROL_MODE = 4  # 扩展位置控制模式

# Add definition for the Hardware Error Status address if it's not in robotis_def
ADDR_HARDWARE_ERROR_STATUS = 70

# 系统相关配置
SYSTEM = platform.system()

class L30HandAPI:
    """
    L30机械手控制API类
    提供了所有与机械手通信和控制相关的功能
    """

    def __init__(self):
        """
        初始化API实例
        设置默认的通信参数和初始状态
        """
        # 通信相关变量
        self.portHandler = None
        self.packetHandler = None
        self.groupSyncWrite = None
        self.groupSyncRead = None
        self.serial_port = None
        self.is_connected = False

        # 电机状态相关
        self.is_calibrated = False
        self.motor_limits = {}  # 存储电机行程限制值
        self.connected_motors = set()  # 已连接的电机ID集合
        self.motors = {}  # 保证属性总是存在

        # 配置参数
        self.config = {
            'baudrate': 1000000,  # 波特率1M
            'protocol_version': 2.0,  # Dynamixel协议2.0版本
            'timeout': 20,  # 通信超时时间（毫秒），从100ms降低以加快扫描速度
            'min_position': 0,  # 最小位置值
            'max_position': 4095,  # 最大位置值（12位分辨率）
            'default_velocity': 255,  # 默认速度值
            'password': '150613'  # 校准密码
        }

        self.current_positions = {}
        self.motor_torque_enabled = {}
        self.initial_positions = {}  # 存储上电时读取的原始位置

    def get_available_ports(self) -> List[str]:
        """获取系统中可用的串口列表"""
        ports = []
        for port in serial.tools.list_ports.comports():
            ports.append(port.device)
        return ports

    def connect_motor(self, port: str) -> Tuple[bool, str, str]:
        """
        连接到指定串口的电机

        Args:
            port: 串口名称

        Returns:
            (success, message, hand_type): 连接是否成功及相关信息和当前手型
        """
        print(f"\n正在连接串口 {port}...")
        self.motors = {}  # 确保每次连接前都初始化
        try:
            # 初始化变量
            offline_motors = []

            # 如果已经连接，先断开
            if self.portHandler and self.portHandler.is_open:
                try:
                    print("检测到已有连接，正在断开...")
                    self.portHandler.closePort()
                    time.sleep(0.2)  # 等待串口完全关闭
                except:
                    pass

            # 创建串口处理器
            self.portHandler = PortHandler(port)
            self.packetHandler = PacketHandler(self.config['protocol_version'])

            # 设置串口参数
            self.portHandler.setPacketTimeout(self.config['timeout'])
            self.portHandler.setPacketTimeoutMillis(self.config['timeout'])

            # 尝试打开串口
            port_open_retries = 1
            port_opened = False

            for i in range(port_open_retries):
                try:
                    print(f"尝试打开串口 (第 {i + 1} 次)...")
                    if self.portHandler.openPort():
                        port_opened = True
                        break
                    time.sleep(0.1)
                except:
                    time.sleep(0.1)
                    continue

            if not port_opened:
                print("错误：无法打开串口")
                if not self.motors:
                    print("警告：motors未初始化，可能未成功连接电机")
                return False, "无法打开串口", 'unknown'

            # 设置波特率
            print(f"设置波特率: {self.config['baudrate']}...")
            if not self.portHandler.setBaudRate(self.config['baudrate']):
                self.portHandler.closePort()
                print("错误：无法设置波特率")
                if not self.motors:
                    print("警告：motors未初始化，可能未成功连接电机")
                return False, "无法设置波特率", 'unknown'

            print("等待串口稳定...")
            time.sleep(0.5)

            # 创建同步读写对象
            print("初始化通信对象...")
            self.groupSyncWrite = GroupSyncWrite(self.portHandler,
                                                 self.packetHandler,
                                                 ADDR_GOAL_POSITION, 4)
            self.groupSyncWriteVel = GroupSyncWrite(self.portHandler,
                                                    self.packetHandler,
                                                    ADDR_PROFILE_VELOCITY, 4)
            self.groupSyncRead = GroupSyncRead(self.portHandler,
                                               self.packetHandler,
                                               ADDR_PRESENT_POSITION, 4)

            # 先ping 17和117号电机，优先识别左右手
            detected_wrist_id = None
            for wrist_id in [17, 117]:
                print(f"尝试识别手腕电机ID: {wrist_id}")
                online, _ = self.ping_motor(wrist_id)
                if online:
                    detected_wrist_id = wrist_id
                    from motor_mapping import set_and_get_hand_type_by_wrist_id
                    hand_type = set_and_get_hand_type_by_wrist_id(detected_wrist_id)
                    print(f"识别到手腕电机ID: {detected_wrist_id}，当前为{'左手' if hand_type == 'left' else '右手' if hand_type == 'right' else '未知'}")
                    break

            # 自动识别左右手
            hand_type = 'unknown'
            if detected_wrist_id is not None:
                from motor_mapping import set_and_get_hand_type_by_wrist_id
                hand_type = set_and_get_hand_type_by_wrist_id(detected_wrist_id)
                print(f"识别到手腕电机ID: {detected_wrist_id}，当前为{'左手' if hand_type == 'left' else '右手' if hand_type == 'right' else '未知'}")
            else:
                print("未检测到手腕电机ID，无法自动识别左右手")

            # 初始化电机状态
            if detected_wrist_id == 117:  # 左手
                scan_ids = list(range(1, 17)) + [117]
            else:  # 右手或未检测到
                scan_ids = list(range(1, 18))

            # 初始化电机字典
            self.motors = {}
            for motor_id in scan_ids:
                # 检查电机是否在线
                online, _ = self.ping_motor(motor_id)
                if online:
                    self.motors[motor_id] = {
                        'enabled': False,
                        'position': 0
                    }
                else:
                    print(f"电机 {motor_id} 离线")
                    offline_motors.append(motor_id)

            print("connect_motor初始化后motors：", self.motors)

            self.is_connected = True
            connection_message = "连接成功"

            print("\n串口连接成功！")
            if offline_motors:
                print(f"警告：以下电机未响应: {offline_motors}")

            # 连接成功后自动启用电机出力
            print("\n正在启用电机出力...")
            if self.set_all_torque(True):
                print("电机出力启用成功")

                # 读取所有电机当前位置（上电后初始读取）
                print("\n读取电机当前位置...")
                current_positions = self.read_current_positions(is_initial_read=True)
                if current_positions:
                    print("\n当前电机位置:")
                    for motor_id, position in current_positions.items():
                        # 将电机角度转换为关节角度
                        joint_angle = self.motor_to_joint_angle(motor_id, position)
                        print(f"电机 {motor_id}: 电机角度 = {position:.1f}°, 关节角度 = {joint_angle:.1f}°")
                else:
                    print("警告：无法读取电机位置")
            else:
                print("警告：电机出力启用失败")

            if not self.motors:
                print("警告：motors未初始化，可能未成功连接电机")
            return True, connection_message, hand_type

        except Exception as e:
            if self.portHandler and self.portHandler.is_open:
                self.portHandler.closePort()
            self.is_connected = False
            error_msg = str(e)
            print(f"\n连接失败：{error_msg}")
            if not self.motors:
                print("警告：motors未初始化，可能未成功连接电机")
            return False, error_msg, 'unknown'

    def disconnect_motor(self) -> bool:
        """
        断开与电机的连接

        Returns:
            bool: 是否成功断开连接
        """
        print("\n正在断开连接...")
        if not self.is_connected:
            print("已经处于断开状态")
            return True

        try:
            # 关闭所有电机使能
            print("关闭所有电机使能...")
            for motor_id in self.motors.keys():
                if self.motors[motor_id]['enabled']:
                    try:
                        print(f"禁用电机 {motor_id}...")
                        # 禁用电机
                        self.packetHandler.write1ByteTxRx(
                            self.portHandler, motor_id, ADDR_TORQUE_ENABLE, TORQUE_DISABLE)
                        # 清除目标位置
                        self.packetHandler.write4ByteTxRx(
                            self.portHandler, motor_id, ADDR_GOAL_POSITION, 0)
                        # 清除速度设置
                        self.packetHandler.write4ByteTxRx(
                            self.portHandler, motor_id, ADDR_PROFILE_VELOCITY, 0)
                    except:
                        print(f"警告：禁用电机 {motor_id} 时出错")
                        continue

            # 关闭串口
            if self.portHandler and self.portHandler.is_open:
                print("关闭串口...")
                self.portHandler.closePort()

            # 重置状态
            self.is_connected = False
            self.connected_motors.clear()
            for motor_id in self.motors:
                self.motors[motor_id]['enabled'] = False

            print("断开连接成功")
            return True
        except Exception as e:
            print(f"断开连接时出错: {str(e)}")
            return False

    def calibrate_hand(self, password: str) -> Tuple[bool, str]:
        """
        手部校准功能

        Args:
            password: 校准密码

        Returns:
            (success, message): 校准是否成功及相关信息
        """
        print("\n开始手部校准...")

        # 验证密码
        if not password or password != "150613":
            print("校准失败：密码错误")
            return False, "密码错误"

        if not self.is_connected:
            print("校准失败：未连接到电机")
            return False, "未连接到电机"

        try:
            print("关闭电机出力，让用户可以手动调整位置...")
            # 关闭电机出力，让用户可以手动调整位置
            self.set_all_torque(False)

            # 获取所有关节名称和对应的电机ID
            failed_motors = []
            success_count = 0

            print("\n开始读取各关节位置...")
            # 一次性读取所有电机的位置
            from motor_mapping import get_table_columns, get_motor_id
            for col_name in get_table_columns()[1:]:
                motor_id = get_motor_id(col_name)
                if not motor_id:
                    continue

                # 获取关节信息
                from motor_mapping import get_joint_info
                joint_info = get_joint_info(motor_id)
                if not joint_info:
                    continue

                try:
                    # 先将homing offset设为0
                    result, error = self.packetHandler.write4ByteTxRx(
                        self.portHandler, motor_id, ADDR_HOMING_OFFSET, 0)

                    if result != COMM_SUCCESS or error != 0:
                        failed_motors.append(f"{col_name} (ID: {motor_id})")
                        print(f"警告：设置电机 {motor_id} ({col_name}) homing offset为0失败")
                        continue

                    # 等待0.001秒
                    time.sleep(0.05)

                    # 读取当前位置
                    current_position, result, error = self.packetHandler.read4ByteTxRx(
                        self.portHandler, motor_id, ADDR_PRESENT_POSITION)

                    if result != COMM_SUCCESS or error != 0:
                        failed_motors.append(f"{col_name} (ID: {motor_id})")
                        print(f"警告：读取电机 {motor_id} ({col_name}) 位置失败")
                        continue

                    # 计算新的homing offset: 2048 - current_position
                    new_offset = 2048 - current_position

                    print(f"\n电机 {motor_id} ({col_name}):")
                    print(f"  当前位置: {current_position}")
                    print(f"  新offset: {new_offset}")
                    time.sleep(0.05)
                    # 设置新的homing offset
                    result, error = self.packetHandler.write4ByteTxRx(
                        self.portHandler, motor_id, ADDR_HOMING_OFFSET, new_offset)

                    if result != COMM_SUCCESS or error != 0:
                        print(f"警告：设置电机 {motor_id} homing offset失败")
                        failed_motors.append(f"{col_name} (ID: {motor_id})")
                        continue

                    # 重新读取位置以验证offset效果
                    time.sleep(0.05)
                    new_position, result, error = self.packetHandler.read4ByteTxRx(
                        self.portHandler, motor_id, ADDR_PRESENT_POSITION)

                    if result == COMM_SUCCESS and error == 0:
                        new_angle = (new_position * 360.0 / DXL_MAXIMUM_POSITION_VALUE) % 360
                        print(f"  校准后位置: {new_angle:.1f}°")
                        success_count += 1

                except Exception as e:
                    failed_motors.append(f"{col_name} (ID: {motor_id})")
                    print(f"警告：校准电机 {motor_id} 时出错: {str(e)}")
                    continue

            print("\n重新启用电机出力...")
            # 重新启用电机出力
            self.set_all_torque(True)

            time.sleep(0.05)

            print("\n读取电机当前位置...")
            current_positions = self.read_current_positions(is_initial_read=True)
            if current_positions:
                print("\n当前电机位置:")
                for motor_id, position in current_positions.items():
                    # 将电机角度转换为关节角度
                    joint_angle = self.motor_to_joint_angle(motor_id, position)
                    print(f"电机 {motor_id}: 电机角度 = {position:.1f}°, 关节角度 = {joint_angle:.1f}°")

            # 检查是否有校准失败的电机
            if failed_motors:
                error_message = "以下关节校准失败：\n" + "\n".join(failed_motors)
                print(f"\n校准失败：\n{error_message}")
                return False, error_message

            if success_count == 0:
                print("\n校准失败：没有成功校准任何电机")
                return False, "没有成功校准任何电机"

            print(f"\n校准完成！成功校准 {success_count} 个关节")
            return True, f"成功校准 {success_count} 个关节"

        except Exception as e:
            print(f"\n校准失败：{str(e)}")
            return False, f"校准失败: {str(e)}"

    def get_uncalibrated_motors(self) -> list:
        """
        检查所有连接的电机，返回Homing Offset为0的电机ID列表。

        Returns:
            list: Homing Offset为0的电机ID列表。
        """
        if not self.is_connected:
            print("错误：未连接到电机")
            return []

        uncalibrated_motors = []
        # 检查所有可能的电机ID
        for motor_id in self.motors.keys():
            # 只检查被API识别为已连接并启用的电机
            if not self.motors[motor_id].get('enabled', False):
                continue

            try:
                homing_offset, result, error = self.packetHandler.read4ByteTxRx(
                    self.portHandler, motor_id, ADDR_HOMING_OFFSET)

                if result == COMM_SUCCESS and error == 0:
                    # Dynamixel SDK返回一个32位无符号值，需要转换为有符号整数
                    if homing_offset > 2147483647:  # 2^31 - 1
                        homing_offset -= 4294967296  # 2^32

                    if homing_offset == 0:
                        uncalibrated_motors.append(motor_id)
                else:
                    # 记录错误，但不中断检查
                    print(f"警告：无法读取电机 {motor_id} 的 Homing Offset。")
            except Exception as e:
                print(f"警告：读取电机 {motor_id} Homing Offset 时出错: {e}")

        return uncalibrated_motors

    def limit_angle(self, motor_id: int, angle: float) -> float:
        """
        根据校准限制值限制角度

        Args:
            motor_id (int): 电机ID
            angle (float): 目标角度（关节角度，UI显示值）

        Returns:
            float: 限制后的角度值
        """
        from motor_mapping import get_joint_info
        joint_info = get_joint_info(motor_id)
        if joint_info:
            min_angle, max_angle = joint_info['range']
            return max(min_angle, min(max_angle, angle))
        return angle

    def joint_to_motor_angle(self, motor_id: int, joint_angle: float) -> float:
        """
        将关节角度转换为电机角度

        Args:
            motor_id: 电机ID
            joint_angle: 关节角度（UI显示值）

        Returns:
            float: 电机角度值
        """
        # 获取关节信息
        from motor_mapping import get_joint_info
        joint_info = get_joint_info(motor_id)
        if not joint_info:
            print(f"警告：电机 {motor_id} 未找到关节信息，使用原始角度")
            return joint_angle

        # 获取关节范围
        min_angle, max_angle = joint_info['range']

        # 限制关节角度在有效范围内
        clamped_angle = max(min_angle, min(max_angle, joint_angle))

        # 根据方向调整角度
        if joint_info.get('direction', 1) < 0:
            # 反向映射
            motor_angle = 180 - clamped_angle
        else:
            motor_angle = clamped_angle + 180

        print(
            f"电机 {motor_id} - 关节角度 {joint_angle:.1f}° (限制后: {clamped_angle:.1f}°) 转换为电机角度 {motor_angle:.1f}°")
        return motor_angle

    def motor_to_joint_angle(self, motor_id: int, motor_angle: float) -> float:
        """
        将电机角度转换为关节角度

        Args:
            motor_id: 电机ID
            motor_angle: 电机角度值

        Returns:
            float: 关节角度（UI显示值）
        """
        # 获取关节信息
        from motor_mapping import get_joint_info
        joint_info = get_joint_info(motor_id)
        if not joint_info:
            print(f"警告：电机 {motor_id} 未找到关节信息，使用原始角度")
            return motor_angle

        # 获取关节范围
        min_angle, max_angle = joint_info['range']

        # 根据方向调整角度
        if joint_info.get('direction', 1) < 0:
            # 反向映射
            joint_angle = 180 - motor_angle
        else:
            joint_angle = motor_angle - 180

        # 限制关节角度在有效范围内
        joint_angle = max(min_angle, min(max_angle, joint_angle))

        print(f"电机 {motor_id} - 电机角度 {motor_angle:.1f}° 转换为关节角度 {joint_angle:.1f}°")
        return joint_angle

    def _adjust_angle_for_setting(self, motor_id: int, angle: float) -> float:
        """
        根据上电读取的位置调整设置角度

        Args:
            motor_id: 电机ID
            angle: 目标角度

        Returns:
            float: 调整后的角度
        """
        # 如果没有初始位置记录，直接返回原角度
        if motor_id not in self.initial_positions:
            return angle

        initial_pos = self.initial_positions[motor_id]

        # 根据上电读取的位置调整设置值
            # 根据上电时的调整方向，设置时进行反向调整
        if initial_pos < 0:  # 上电时小于0，加了360
            # 设置时：小于0加360，大于360减360
            return angle - 360
        elif initial_pos > 360:  # 上电时大于360，减了360
            # 设置时：小于0加360，大于360减360
            return angle + 360

        return angle

    def set_motor_position(self, motor_id: int, angle: float) -> bool:
        """
        设置单个电机位置

        Args:
            motor_id (int): 电机ID
            angle (float): 目标角度（电机角度）

        Returns:
            bool: 设置是否成功
        """
        if not self.is_connected:
            return False

        try:
            # 根据上电读取的位置调整设置角度
            adjusted_angle = self._adjust_angle_for_setting(motor_id, angle)

            # 将角度转换为位置值（扩展位置控制模式支持多圈）
            position = int(adjusted_angle * (DXL_MAXIMUM_POSITION_VALUE / 360.0))
            # 扩展位置控制模式范围：-1,048,575 ~ 1,048,575
            position = min(max(-1048575, position), 1048575)
            print(f"电机 {motor_id}: 目标角度 {angle:.1f}° -> 调整后角度 {adjusted_angle:.1f}° -> 位置值 {position}")

            # 设置位置
            dxl_comm_result, dxl_error = self.packetHandler.write4ByteTxRx(
                self.portHandler, motor_id, ADDR_GOAL_POSITION, position)

            if dxl_comm_result != COMM_SUCCESS or dxl_error != 0:
                if motor_id in self.motors:
                    self.motors[motor_id]['enabled'] = False
                return False
            return True
        except Exception as e:
            if motor_id in self.motors:
                self.motors[motor_id]['enabled'] = False
            return False

    def set_motors_position_sync(self, motor_positions):
        """
        同步设置多个电机位置

        Args:
            motor_positions (dict): 电机ID和目标角度的映射，角度值为电机角度（不是关节角度）

        Returns:
            bool: 设置是否成功
        """
        if not self.is_connected or not self.groupSyncWrite:
            return False

        # 最大重试次数和当前重试次数
        max_retries = 10
        retry_count = 0
        retry_delay = 0.02  # 重试延迟20ms

        while retry_count < max_retries:
            # 清除之前的数据
            self.groupSyncWrite.clearParam()

            # 添加每个电机的位置数据
            failed_motors = []
            for motor_id, motor_angle in motor_positions.items():
                if not self.motors[motor_id]['enabled']:
                    continue

                try:
                    # 根据上电读取的位置调整设置角度
                    adjusted_angle = self._adjust_angle_for_setting(motor_id, motor_angle)

                    # 将调整后的电机角度转换为位置值（扩展位置控制模式支持多圈）
                    position = int(adjusted_angle * (DXL_MAXIMUM_POSITION_VALUE / 360.0))
                    # 扩展位置控制模式范围：-1,048,575 ~ 1,048,575
                    position = min(max(-1048575, position), 1048575)

                    # 将位置值转换为字节数组
                    param = [DXL_LOBYTE(DXL_LOWORD(position)),
                             DXL_HIBYTE(DXL_LOWORD(position)),
                             DXL_LOBYTE(DXL_HIWORD(position)),
                             DXL_HIBYTE(DXL_HIWORD(position))]

                    # 添加参数
                    if not self.groupSyncWrite.addParam(motor_id, param):
                        failed_motors.append(motor_id)
                        self.motors[motor_id]['enabled'] = False
                except:
                    failed_motors.append(motor_id)
                    self.motors[motor_id]['enabled'] = False

            if failed_motors:
                return False  # 如果参数添加失败，直接返回False

            # 同步写入所有电机位置
            comm_result = self.groupSyncWrite.txPacket()
            if comm_result == COMM_SUCCESS:
                return True  # 写入成功，直接返回

            # 分析通信错误原因
            error_msg = ""
            if comm_result == COMM_TX_FAIL:
                # 检查串口状态
                if not self.portHandler.is_open:
                    error_msg = "串口已断开连接"
                else:
                    error_msg = "发送数据失败，可能是串口通信错误"
            elif comm_result == COMM_PORT_BUSY:
                error_msg = "COMM_PORT_BUSY"
            elif comm_result == COMM_RX_FAIL:
                error_msg = "接收数据失败，可能是电机未响应"
            elif comm_result == COMM_TX_ERROR:
                error_msg = "数据发送错误，可能是数据包格式错误"
            elif comm_result == COMM_RX_WAITING:
                error_msg = "等待接收数据超时"
            elif comm_result == COMM_RX_TIMEOUT:
                error_msg = "接收数据超时，检查电机是否掉线"
            elif comm_result == COMM_RX_CORRUPT:
                error_msg = "数据校验错误，可能存在干扰"
            else:
                error_msg = f"未知通信错误: {comm_result}"

            print(f"通信错误（重试 {retry_count + 1}/{max_retries}）: {error_msg}")

            # 如果是串口断开，尝试重新连接
            if not self.portHandler.is_open:
                try:
                    self.portHandler.closePort()
                    time.sleep(0.1)  # 等待串口完全关闭
                    if self.portHandler.openPort():
                        print("串口重新连接成功")
                    else:
                        print("串口重新连接失败")
                        break  # 如果重连失败，退出重试
                except:
                    print("串口重新连接失败")
                    break  # 如果重连失败，退出重试

            retry_count += 1
            if retry_count < max_retries:
                time.sleep(retry_delay)  # 延时后重试

        # 所有重试都失败，将电机标记为不可用
        for motor_id in motor_positions:
            if self.motors[motor_id]['enabled']:
                self.motors[motor_id]['enabled'] = False

        return False

    def set_all_velocity_sync(self, velocity):
        """
        同步设置所有启用电机的速度

        Args:
            velocity (int): 目标速度值

        Returns:
            bool: 设置是否成功

        处理步骤：
        1. 检查连接状态
        2. 清除之前的同步写入参数
        3. 为每个启用的电机添加速度参数
        4. 执行同步写入操作
        """
        if not self.is_connected or not self.groupSyncWriteVel:
            return False

        # 清除之前的数据
        self.groupSyncWriteVel.clearParam()

        # 添加每个电机的速度数据
        for motor_id in self.motors.keys():
            if not self.motors[motor_id]['enabled']:
                continue
            if velocity == 0:
                velocity = 1
            # 将速度值转换为字节数组
            param = [DXL_LOBYTE(DXL_LOWORD(velocity)),
                     DXL_HIBYTE(DXL_LOWORD(velocity)),
                     DXL_LOBYTE(DXL_HIWORD(velocity)),
                     DXL_HIBYTE(DXL_HIWORD(velocity))]

            # 添加参数
            if not self.groupSyncWriteVel.addParam(motor_id, param):
                return False

        # 同步写入所有电机速度
        dxl_comm_result = self.groupSyncWriteVel.txPacket()
        return dxl_comm_result == COMM_SUCCESS

    def read_current_positions(self, is_initial_read=False) -> Dict[int, float]:
        """
        读取所有启用电机的当前位置

        Args:
            is_initial_read: 是否为上电后的初始读取

        Returns:
            Dict[int, float]: 电机ID和当前位置的字典
        """
        if not self.is_connected:
            return {}

        positions = {}
        offline_motors = []

        # 只读取self.motors中存在的电机
        for motor_id in list(self.motors.keys()):
            print(f"尝试读取电机 {motor_id}，enabled={self.motors[motor_id]['enabled']}")
            if not self.motors[motor_id]['enabled']:
                continue

            try:
                # 读取当前位置
                position, result, error = self.packetHandler.read4ByteTxRx(
                    self.portHandler, motor_id, ADDR_PRESENT_POSITION)

                if result == COMM_SUCCESS and error == 0:
                    # 将位置值转换为电机角度（扩展位置控制模式支持多圈）
                    # 需要处理有符号32位整数
                    if position > 2147483647:  # 如果是无符号读取，转换为有符号
                        position = position - 4294967296

                    # 转换为角度（支持多圈，不限制在0-360范围内）
                    motor_angle = position * 360.0 / DXL_MAXIMUM_POSITION_VALUE

                    if is_initial_read:
                        # 上电后初始读取，存储原始位置
                        self.initial_positions[motor_id] = motor_angle

                        # 将角度标准化到0-360范围来判断是否需要调整
                        normalized_angle = motor_angle % 360

                    if motor_angle < 0:
                        adjusted_angle = motor_angle + 360
                        print(f"电机 {motor_id}: 原始角度 {motor_angle:.1f}°(小于0) -> 调整后角度 {adjusted_angle:.1f}°")
                        motor_angle = adjusted_angle
                    elif motor_angle > 360:
                        adjusted_angle = motor_angle - 360
                        print(f"电机 {motor_id}: 原始角度 {motor_angle:.1f}°(大于360) -> 调整后角度 {adjusted_angle:.1f}°")
                        motor_angle = adjusted_angle

                    positions[motor_id] = motor_angle
                else:
                    offline_motors.append(motor_id)
                    self.motors[motor_id]['enabled'] = False
            except:
                offline_motors.append(motor_id)
                self.motors[motor_id]['enabled'] = False

        return positions

    def save_current_positions(self) -> Dict[int, float]:
        """
        保存当前所有关节角度

        Returns:
            Dict[int, float]: 电机ID和关节角度的字典
        """
        if not self.is_connected:
            return {}

        positions = {}
        offline_motors = []

        # 只保存self.motors中存在的电机
        for motor_id in list(self.motors.keys()):
            if not self.motors[motor_id]['enabled']:
                continue

            try:
                # 读取当前位置
                position, result, error = self.packetHandler.read4ByteTxRx(
                    self.portHandler, motor_id, ADDR_PRESENT_POSITION)

                if result == COMM_SUCCESS and error == 0:
                    # 将位置值转换为电机角度（扩展位置控制模式支持多圈）
                    # 需要处理有符号32位整数
                    if position > 2147483647:  # 如果是无符号读取，转换为有符号
                        position = position - 4294967296

                    # 转换为角度（支持多圈，不限制在0-360范围内）
                    motor_angle = position * 360.0 / DXL_MAXIMUM_POSITION_VALUE

                    # 如果有初始位置记录，应用相同的调整逻辑
                    if motor_id in self.initial_positions:
                        initial_pos = self.initial_positions[motor_id]
                        normalized_initial = initial_pos % 360

                        if not (90 <= normalized_initial <= 270):
                            # 与初始读取时相同的调整逻辑：小于0加360，大于360减360
                            if motor_angle < 0:
                                motor_angle = motor_angle + 360
                            elif motor_angle > 360:
                                motor_angle = motor_angle - 360

                    # 转换为关节角度
                    joint_angle = self.motor_to_joint_angle(motor_id, motor_angle)
                    positions[motor_id] = joint_angle
                else:
                    offline_motors.append(motor_id)
                    self.motors[motor_id]['enabled'] = False
            except:
                offline_motors.append(motor_id)
                self.motors[motor_id]['enabled'] = False

        return positions

    def open_hand(self) -> bool:
        """
        执行五指张开动作（所有关节设置为0度）

        Returns:
            bool: 是否成功执行动作
        """
        if not self.is_connected:
            return False

        # 将所有关节的目标角度设置为0
        from motor_mapping import get_table_columns, get_motor_id
        joint_positions = {}
        for col_name in get_table_columns()[1:]:  # 跳过序号列
            motor_id = get_motor_id(col_name)
            # 只处理self.motors中存在的电机
            if motor_id and motor_id in self.motors:
                joint_positions[motor_id] = 0  # 所有关节角度设为0度（张开状态）

        # 准备所有电机的位置数据
        motor_positions = {}
        for motor_id, joint_angle in joint_positions.items():
            if motor_id in self.motors and self.motors[motor_id]['enabled']:
                # 先限制关节角度范围
                limited_joint_angle = self.limit_angle(motor_id, joint_angle)
                # 将关节角度转换为电机角度
                motor_angle = self.joint_to_motor_angle(motor_id, limited_joint_angle)
                motor_positions[motor_id] = motor_angle
                print(f"设置电机 {motor_id} - 关节角度: {limited_joint_angle:.1f}°, 电机角度: {motor_angle:.1f}°")

        # 同步设置所有电机位置
        return self.set_motors_position_sync(motor_positions)

    def close_hand(self) -> bool:
        """
        执行五指握拳动作

        Returns:
            bool: 是否成功执行动作
        """
        if not self.is_connected:
            return False

        try:
            # 设置所有指根关节为最大角度
            positions = {}
            for motor_id in [1, 3, 5, 7, 9]:  # 只控制指根关节
                # 只处理self.motors中存在的电机
                if motor_id in self.motors:
                    from motor_mapping import get_joint_info
                    joint_info = get_joint_info(motor_id)
                    if joint_info:
                        positions[motor_id] = joint_info['range'][1]

            return self.set_motors_position_sync(positions)
        except:
            return False

    def toggle_all_torque(self) -> Tuple[bool, bool]:
        """
        切换所有电机的使能状态
        根据当前状态执行使能或禁用操作

        Returns:
            (success, new_state): 是否成功切换及新的出力状态
        """
        if not self.is_connected:
            print("错误：未连接到电机")
            return False, False

        # 获取当前电机状态
        current_state = False
        for motor_id in self.motors.keys():
            if self.motors[motor_id]['enabled']:
                # 读取电机的实际使能状态
                try:
                    torque_enabled, _, _ = self.packetHandler.read1ByteTxRx(
                        self.portHandler, motor_id, ADDR_TORQUE_ENABLE)
                    if torque_enabled == TORQUE_ENABLE:
                        current_state = True
                        break
                except:
                    continue

        # 切换状态
        new_state = not current_state
        print(f"\n{'启用' if new_state else '禁用'}所有电机出力...")
        success = self.set_all_torque(new_state)

        if success:
            print(f"电机出力状态切换成功：{'已启用' if new_state else '已禁用'}")
            # 确保所有电机状态一致
            for motor_id in self.motors:
                self.motors[motor_id]['enabled'] = new_state
        else:
            print("电机出力状态切换失败")

        return success, new_state

    def set_all_torque(self, enable: bool) -> bool:
        """
        设置所有电机的出力状态

        Args:
            enable (bool): True表示使能，False表示禁用

        Returns:
            bool: 设置是否成功
        """
        if not self.is_connected:
            print("错误：未连接到电机")
            return False

        print(f"\n{'启用' if enable else '禁用'}所有电机出力...")
        torque_value = TORQUE_ENABLE if enable else TORQUE_DISABLE
        offline_motors = []

        # 只操作self.motors中存在的电机
        for motor_id in list(self.motors.keys()):
            try:
                # 如果是使能操作，先设置位置控制模式
                if enable:
                    print(f"设置电机 {motor_id} 为扩展位置控制模式...")
                    dxl_comm_result, dxl_error = self.packetHandler.write1ByteTxRx(
                        self.portHandler, motor_id, ADDR_OPERATING_MODE, EXTENDED_POSITION_CONTROL_MODE)
                    if dxl_comm_result != COMM_SUCCESS or dxl_error != 0:
                        offline_motors.append(motor_id)
                        print(f"警告：电机 {motor_id} 设置控制模式失败")
                        continue

                # 设置出力状态
                print(f"{'启用' if enable else '禁用'}电机 {motor_id} 出力...")
                dxl_comm_result, dxl_error = self.packetHandler.write1ByteTxRx(
                    self.portHandler, motor_id, ADDR_TORQUE_ENABLE, torque_value)

                if dxl_comm_result != COMM_SUCCESS or dxl_error != 0:
                    offline_motors.append(motor_id)
                    print(f"警告：电机 {motor_id} {'启用' if enable else '禁用'}失败")
                    if motor_id in self.motors:
                        self.motors[motor_id]['enabled'] = False
                else:
                    # 安全地更新电机状态
                    if motor_id in self.motors:
                        self.motors[motor_id]['enabled'] = enable
                    print(f"电机 {motor_id} {'启用' if enable else '禁用'}成功")

                    # 如果是关闭出力，确保电机完全断电
                    if not enable:
                        print(f"清除电机 {motor_id} 的目标位置和速度设置...")
                        # 清除目标位置
                        self.packetHandler.write4ByteTxRx(
                            self.portHandler, motor_id, ADDR_GOAL_POSITION, 0)
                        # 清除速度设置
                        self.packetHandler.write4ByteTxRx(
                            self.portHandler, motor_id, ADDR_PROFILE_VELOCITY, 0)
            except Exception as e:
                offline_motors.append(motor_id)
                print(f"警告：设置电机 {motor_id} 出力状态时出错: {str(e)}")
                if motor_id in self.motors:
                    self.motors[motor_id]['enabled'] = False

        if offline_motors:
            print(f"\n警告：以下电机操作失败: {offline_motors}")
            return False
        print("\n所有电机出力状态设置完成")
        # 末尾加调试输出
        print("set_all_torque后motors状态：", {k: v['enabled'] for k, v in self.motors.items()})
        return True

    def ping_motor(self, motor_id: int) -> Tuple[bool, str]:
        """
        通过ping指令检查电机是否在线。

        Args:
            motor_id (int): 电机ID

        Returns:
            tuple: (是否在线, 错误信息)
        """
        if not self.portHandler or not self.portHandler.is_open:
            return False, "串口未打开"

        try:
            # 清除输入缓冲区，以确保接收到新的响应
            self.portHandler.clearPort()

            # 发送 ping 指令
            dxl_model_number, dxl_comm_result, dxl_error = self.packetHandler.ping(
                self.portHandler, motor_id)

            # 增加一个微小的延时，提高通信稳定性
            time.sleep(0.01)

            if dxl_comm_result != COMM_SUCCESS:
                error_msg = self.packetHandler.getTxRxResult(dxl_comm_result)
                print(f"电机 {motor_id} ping失败: {error_msg}")
                return False, error_msg
            elif dxl_error != 0:
                error_msg = self.packetHandler.getRxPacketError(dxl_error)

                # 尝试读取硬件错误状态以获取更详细的信息
                try:
                    hw_error_status, _, _ = self.packetHandler.read1ByteTxRx(self.portHandler, motor_id,
                                                                             ADDR_HARDWARE_ERROR_STATUS)
                    if hw_error_status != 0:
                        detailed_errors = []
                        if (hw_error_status & 1): detailed_errors.append("Input Voltage")
                        if (hw_error_status & 4): detailed_errors.append("Overheating")
                        if (hw_error_status & 8): detailed_errors.append("Motor Encoder")
                        if (hw_error_status & 16): detailed_errors.append("Electrical Shock")
                        if (hw_error_status & 32): detailed_errors.append("Overload")

                        if detailed_errors:
                            error_msg += f" (Details: {', '.join(detailed_errors)})"
                except Exception:
                    # 如果读取详细状态失败，也没关系，主错误信息已经足够
                    pass

                print(f"电机 {motor_id} 硬件错误: {error_msg}")
                return False, error_msg

            print(f"电机 {motor_id} 在线 (型号: {dxl_model_number})")
            return True, ""

        except Exception as e:
            error_msg = f"ping电机 {motor_id} 时发生未知错误: {str(e)}"
            print(error_msg)
            return False, error_msg 